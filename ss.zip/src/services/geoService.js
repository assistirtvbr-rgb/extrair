/**
 * Accurate Geocoding & Geolocation Service
 * Uses OpenStreetMap Nominatim with strict validation and no silent fallback to wrong cities.
 */

export class LocationNotFoundError extends Error {
  constructor(query) {
    super(`Não foi possível localizar o endereço "${query}". Por favor, informe uma cidade, bairro ou CEP mais específico (ex: "Belford Roxo - RJ" ou "Tijuca, Rio de Janeiro").`);
    this.name = 'LocationNotFoundError';
    this.query = query;
  }
}

export const geoService = {
  /**
   * Geocode an address/neighborhood/city to lat/lng accurately
   */
  async geocode(query, isDemo = false) {
    if (!query || !query.trim()) {
      throw new Error('Digite um endereço, cidade ou bairro para pesquisar.');
    }

    const trimmed = query.trim();

    try {
      const sanitized = encodeURIComponent(trimmed);
      const url = `https://nominatim.openstreetmap.org/search?q=${sanitized}&format=json&countrycodes=br&limit=1&addressdetails=1`;
      
      const response = await fetch(url, {
        headers: {
          'Accept-Language': 'pt-BR,pt;q=0.9',
          'User-Agent': 'LeadMap-App/2.0'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data && data.length > 0) {
          const item = data[0];
          const address = item.address || {};
          const cityOrTown = address.city || address.town || address.municipality || address.suburb || trimmed;
          const state = address.state ? ` - ${address.state}` : '';
          
          return {
            lat: parseFloat(item.lat),
            lng: parseFloat(item.lon),
            displayName: `${cityOrTown}${state}`,
            name: trimmed
          };
        }
      }
    } catch (e) {
      console.warn('Nominatim network lookup issue:', e);
    }

    // In Demo mode, provide well-known Brazilian municipal centers if Nominatim is unreachable
    if (isDemo) {
      const knownLocations = {
        'belford roxo': { lat: -22.7639, lng: -43.3994, displayName: 'Belford Roxo - RJ' },
        'nova iguacu': { lat: -22.7562, lng: -43.4608, displayName: 'Nova Iguaçu - RJ' },
        'duque de caxias': { lat: -22.7858, lng: -43.3054, displayName: 'Duque de Caxias - RJ' },
        'sao goncalo': { lat: -22.8268, lng: -43.0537, displayName: 'São Gonçalo - RJ' },
        'niteroi': { lat: -22.8832, lng: -43.1034, displayName: 'Niterói - RJ' },
        'tijuca': { lat: -22.9248, lng: -43.2326, displayName: 'Tijuca, Rio de Janeiro - RJ' },
        'barra da tijuca': { lat: -23.0004, lng: -43.3659, displayName: 'Barra da Tijuca, Rio de Janeiro - RJ' },
        'copacabana': { lat: -22.9711, lng: -43.1822, displayName: 'Copacabana, Rio de Janeiro - RJ' },
        'centro rio': { lat: -22.9068, lng: -43.1729, displayName: 'Centro, Rio de Janeiro - RJ' },
        'sao paulo': { lat: -23.5505, lng: -46.6333, displayName: 'São Paulo - SP' },
        'campinas': { lat: -22.9099, lng: -47.0626, displayName: 'Campinas - SP' },
        'curitiba': { lat: -25.4284, lng: -49.2733, displayName: 'Curitiba - PR' },
        'belo horizonte': { lat: -19.9167, lng: -43.9345, displayName: 'Belo Horizonte - MG' },
        'porto alegre': { lat: -30.0346, lng: -51.2177, displayName: 'Porto Alegre - RS' },
        'brasilia': { lat: -15.7975, lng: -47.8919, displayName: 'Brasília - DF' }
      };

      const lower = trimmed.toLowerCase();
      for (const [key, val] of Object.entries(knownLocations)) {
        if (lower.includes(key)) {
          return {
            lat: val.lat,
            lng: val.lng,
            displayName: val.displayName,
            name: trimmed
          };
        }
      }
    }

    // Never return a wrong city in live mode: explicitly throw error so user refines input
    throw new LocationNotFoundError(trimmed);
  },

  /**
   * Reverse geocode coordinates to human readable name
   */
  async reverseGeocode(lat, lng) {
    try {
      const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1`;
      const response = await fetch(url, {
        headers: {
          'Accept-Language': 'pt-BR,pt;q=0.9',
          'User-Agent': 'LeadMap-App/2.0'
        }
      });
      if (response.ok) {
        const data = await response.json();
        const address = data.address || {};
        const suburb = address.suburb || address.neighbourhood || address.city_district;
        const city = address.city || address.town || address.municipality;
        const state = address.state;
        if (suburb && city) {
          return `${suburb}, ${city}${state ? ' - ' + state : ''}`;
        }
        return data.display_name ? data.display_name.split(',').slice(0, 3).join(',') : `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      }
    } catch {
      // fallback
    }
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  },

  /**
   * Browser Geolocation GPS
   */
  getCurrentLocation() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocalização não é suportada pelo seu navegador.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          try {
            const name = await geoService.reverseGeocode(lat, lng);
            resolve({ lat, lng, displayName: name, name });
          } catch {
            resolve({ lat, lng, displayName: 'Minha Localização', name: 'Minha Localização' });
          }
        },
        (error) => {
          let message = 'Não foi possível obter sua localização.';
          if (error.code === error.PERMISSION_DENIED) {
            message = 'Permissão de localização negada pelo usuário.';
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            message = 'Informações de GPS indisponíveis.';
          } else if (error.code === error.TIMEOUT) {
            message = 'Tempo limite esgotado ao buscar GPS.';
          }
          reject(new Error(message));
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }
      );
    });
  }
};
